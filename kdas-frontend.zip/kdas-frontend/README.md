# KDAS Analytics Frontend

Production-oriented React 18 + TypeScript + Vite visualization layer for the KDAS backend.

## Stack

- React 18
- TypeScript
- Vite
- Material UI (MUI)
- MUI DataGrid
- Plotly.js via react-plotly.js
- Axios
- XLSX
- jsPDF + html2canvas

## Backend contract

The frontend calls:

`POST /api/v1/analytics/query`

Request body:

```json
{
  "question": "Compare open vs closed requests by month"
}
```

Optional header:

`X-API-Key: <key>`

The response is expected to contain some or all of:

- `headline`
- `answer`
- `insights`
- `data`
- `columns`
- `chart.type`
- `chart.title`
- `chart.plotly.data`
- `chart.plotly.layout`
- `row_count`
- `telemetry.input_tokens`
- `telemetry.output_tokens`
- `telemetry.total_tokens`
- `telemetry.duration_seconds`
- `telemetry.llm_calls`

Plotly `data` and `layout` are passed to Plotly without reshaping the chart payload.

## Run on your work laptop

1. Install Node.js 20+.
2. Extract this folder.
3. Open a terminal in the project directory.
4. Run:

```bash
npm install
```

5. Copy `.env.example` to `.env`.
6. Set your backend URL:

```env
VITE_BASE_URL=http://YOUR-KDAS-BACKEND-HOST:PORT
VITE_API_KEY=
VITE_MOCK_MODE=false
```

7. Start:

```bash
npm run dev
```

Open the Vite URL shown in the terminal, normally `http://localhost:5173`.

## Build

```bash
npm run build
npm run preview
```

## UI capabilities

- Natural-language query section with API key input
- Executive summary cards for headline, answer and insights
- Plotly line, bar, pie, scatter and histogram payloads
- MUI DataGrid with sorting, filtering, pagination, column resize/hide support from the grid UI, and quick search
- Telemetry KPI cards
- CSV, JSON and Excel exports
- Chart PNG and SVG exports
- PDF report export
- Responsive enterprise dashboard layout
- Dark/light mode
- Loading state
- 401, 500, network, empty-data, no-chart and no-insights handling

## Important security note

A browser-based frontend cannot keep an API key secret. If the KDAS key is privileged, the correct production design is to put authentication/token exchange behind a server-side gateway rather than shipping a permanent secret to the browser. The runtime key field is stored in `sessionStorage`, not persistent localStorage.

## CORS

If the backend and frontend run on different origins, the KDAS backend must allow the frontend origin and the `X-API-Key` request header.
