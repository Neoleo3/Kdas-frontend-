import { useState } from 'react';
import { Box, Button, Card, CardContent, Stack, TextField, Typography } from '@mui/material';
import PlayArrowRoundedIcon from '@mui/icons-material/PlayArrowRounded';
import KeyRoundedIcon from '@mui/icons-material/KeyRounded';

interface Props { loading: boolean; initialKey: string; onRun: (question: string, key: string) => void; }

export function QuerySection({ loading, initialKey, onRun }: Props) {
  const [question, setQuestion] = useState('');
  const [apiKey, setApiKey] = useState(initialKey);

  return (
    <Card sx={{ mb: 2.5 }}>
      <CardContent sx={{ p: { xs: 2, md: 3 } }}>
        <Stack spacing={2}>
          <Box>
            <Typography variant="h6" fontWeight={800}>Ask KDAS</Typography>
            <Typography variant="body2" color="text.secondary">Enter a natural-language analytics question and run the backend analysis.</Typography>
          </Box>
          <TextField
            fullWidth
            multiline
            minRows={2}
            label="Question"
            placeholder="e.g. Compare open vs closed requests by month"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            onKeyDown={(e) => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') onRun(question, apiKey); }}
          />
          <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.5}>
            <TextField
              fullWidth
              label="API Key"
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              InputProps={{ startAdornment: <KeyRoundedIcon sx={{ mr: 1, color: 'text.secondary' }} fontSize="small" /> }}
              helperText="Stored only in this browser session when supplied."
            />
            <Button
              variant="contained"
              size="large"
              startIcon={<PlayArrowRoundedIcon />}
              disabled={loading || !question.trim()}
              onClick={() => onRun(question, apiKey)}
              sx={{ minWidth: 160, alignSelf: { xs: 'stretch', md: 'flex-start' }, height: 56 }}
            >
              {loading ? 'Running…' : 'Run Analysis'}
            </Button>
          </Stack>
        </Stack>
      </CardContent>
    </Card>
  );
}
