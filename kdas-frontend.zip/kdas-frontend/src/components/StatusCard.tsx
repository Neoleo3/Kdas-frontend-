import { Alert, Box, Button, Card, CardContent, Typography } from '@mui/material';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';

export function StatusCard({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return <Card><CardContent><Alert severity="error"><Box><Typography fontWeight={800} sx={{ mb: 0.5 }}>Analysis failed</Typography><Typography variant="body2">{message}</Typography>{onRetry && <Button size="small" startIcon={<RefreshRoundedIcon />} sx={{ mt: 1 }} onClick={onRetry}>Retry</Button>}</Box></Alert></CardContent></Card>;
}
