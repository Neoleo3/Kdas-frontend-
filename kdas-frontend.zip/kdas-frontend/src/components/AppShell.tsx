import { AppBar, Box, IconButton, Toolbar, Typography, Chip, Tooltip } from '@mui/material';
import DarkModeRoundedIcon from '@mui/icons-material/DarkModeRounded';
import LightModeRoundedIcon from '@mui/icons-material/LightModeRounded';
import AnalyticsRoundedIcon from '@mui/icons-material/AnalyticsRounded';

interface Props { dark: boolean; onToggle: () => void; }

export function AppShell({ dark, onToggle }: Props) {
  return (
    <AppBar position="sticky" elevation={0} color="transparent" sx={{ backdropFilter: 'blur(14px)', borderBottom: 1, borderColor: 'divider' }}>
      <Toolbar sx={{ minHeight: 68 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.25, flexGrow: 1 }}>
          <Box sx={{ width: 38, height: 38, borderRadius: 2, display: 'grid', placeItems: 'center', bgcolor: 'primary.main', color: 'primary.contrastText' }}>
            <AnalyticsRoundedIcon fontSize="small" />
          </Box>
          <Box>
            <Typography variant="subtitle1" fontWeight={800} lineHeight={1.1}>KDAS Analytics</Typography>
            <Typography variant="caption" color="text.secondary">Knowledge Driven Analytics System</Typography>
          </Box>
          <Chip label="Enterprise" size="small" variant="outlined" sx={{ ml: 1 }} />
        </Box>
        <Tooltip title={dark ? 'Switch to light mode' : 'Switch to dark mode'}>
          <IconButton onClick={onToggle} aria-label="toggle dark mode">
            {dark ? <LightModeRoundedIcon /> : <DarkModeRoundedIcon />}
          </IconButton>
        </Tooltip>
      </Toolbar>
    </AppBar>
  );
}
