import { Alert, Box, Card, CardContent, Stack, Typography } from '@mui/material';
import LightbulbOutlinedIcon from '@mui/icons-material/LightbulbOutlined';
import type { AnalyticsResponse } from '../models/AnalyticsResponse';

export function ExecutiveSummary({ response }: { response: AnalyticsResponse }) {
  const insights = response.insights || [];
  return (
    <Box sx={{ mb: 2.5 }}>
      <Typography variant="overline" color="primary.main" fontWeight={800} letterSpacing={1.2}>Executive Summary</Typography>
      <Stack spacing={1.5} sx={{ mt: 0.75 }}>
        <Card><CardContent><Typography variant="h5" fontWeight={800}>{response.headline || 'Analysis result'}</Typography></CardContent></Card>
        <Card><CardContent><Typography variant="body1" sx={{ lineHeight: 1.75 }}>{response.answer || 'No answer was returned.'}</Typography></CardContent></Card>
        <Card>
          <CardContent>
            <Stack spacing={1.2}>
              {insights.length ? insights.map((insight, i) => (
                <Box key={`${insight}-${i}`} sx={{ display: 'flex', gap: 1.25, alignItems: 'flex-start' }}>
                  <LightbulbOutlinedIcon color="primary" fontSize="small" sx={{ mt: 0.25 }} />
                  <Typography variant="body2">{insight}</Typography>
                </Box>
              )) : <Alert severity="info">No insights were returned for this query.</Alert>}
            </Stack>
          </CardContent>
        </Card>
      </Stack>
    </Box>
  );
}
