import { useRef } from 'react';
import { Alert, Box, Card, CardContent, Chip, Stack, Typography } from '@mui/material';
import Plot from 'react-plotly.js';
import type { AnalyticsResponse } from '../models/AnalyticsResponse';

interface Props { response: AnalyticsResponse; chartRef?: React.RefObject<HTMLDivElement | null>; }

export function ChartSection({ response, chartRef }: Props) {
  const internalRef = useRef<HTMLDivElement>(null);
  const ref = chartRef || internalRef;
  const plot = response.chart?.plotly;
  if (!plot?.data?.length) {
    return <Card><CardContent><Alert severity="info">No chart was returned for this analysis.</Alert></CardContent></Card>;
  }
  return (
    <Card ref={ref as React.Ref<HTMLDivElement>}>
      <CardContent sx={{ p: { xs: 1, md: 2 } }}>
        <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ px: 1, pb: 1 }}>
          <Box>
            <Typography variant="h6" fontWeight={800}>{response.chart?.title || 'Analysis Chart'}</Typography>
            <Typography variant="caption" color="text.secondary">Rendered directly from backend Plotly JSON</Typography>
          </Box>
          <Chip label={response.chart?.type || 'chart'} size="small" variant="outlined" />
        </Stack>
        <Plot
          data={plot.data as any}
          layout={{ autosize: true, margin: { l: 55, r: 25, t: 35, b: 55 }, paper_bgcolor: 'transparent', plot_bgcolor: 'transparent', ...plot.layout } as any}
          config={{ responsive: true, displaylogo: false, modeBarButtonsToRemove: ['lasso2d', 'select2d'] }}
          useResizeHandler
          style={{ width: '100%', height: 430 }}
          divId="kdas-plot"
        />
      </CardContent>
    </Card>
  );
}
