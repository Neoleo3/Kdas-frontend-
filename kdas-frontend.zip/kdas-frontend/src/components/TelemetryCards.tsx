import { Card, CardContent, Grid, Typography } from '@mui/material';
import type { AnalyticsResponse } from '../models/AnalyticsResponse';

export function TelemetryCards({ response }: { response: AnalyticsResponse }) {
  const t = response.telemetry;
  const items = [
    ['Input Tokens', t?.input_tokens], ['Output Tokens', t?.output_tokens], ['Total Tokens', t?.total_tokens],
    ['Duration Seconds', t?.duration_seconds], ['LLM Calls', t?.llm_calls]
  ];
  return <Grid container spacing={1.5} sx={{ mt: 0.5 }}>{items.map(([label, value]) => (
    <Grid item xs={6} md={2.4} key={String(label)}><Card sx={{ height: '100%' }}><CardContent><Typography variant="caption" color="text.secondary">{label}</Typography><Typography variant="h6" fontWeight={800} sx={{ mt: 0.5 }}>{value ?? '—'}</Typography></CardContent></Card></Grid>
  ))}</Grid>;
}
