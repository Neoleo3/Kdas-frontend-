import { useMemo, useState } from 'react';
import { Box, Card, CardContent, TextField, Typography } from '@mui/material';
import { DataGrid, type GridColDef } from '@mui/x-data-grid';
import type { AnalyticsResponse } from '../models/AnalyticsResponse';

export function DataGridSection({ response }: { response: AnalyticsResponse }) {
  const rows = response.data || [];
  const [search, setSearch] = useState('');
  const columns: GridColDef[] = useMemo(() => {
    const names = response.columns?.length
      ? response.columns.map((column) => typeof column === 'string' ? column : String(column.field ?? column.name ?? 'column'))
      : Array.from(new Set(rows.flatMap((row) => Object.keys(row))));
    return names.map((field) => ({ field, headerName: field.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()), flex: 1, minWidth: 140, sortable: true, filterable: true }));
  }, [response.columns, rows]);
  const filtered = rows.filter((row) => JSON.stringify(row).toLowerCase().includes(search.toLowerCase())).map((row, index) => ({ id: index, ...row }));

  return (
    <Card>
      <CardContent sx={{ p: { xs: 1.5, md: 2 } }}>
        <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', justifyContent: 'space-between', mb: 1.5, flexWrap: 'wrap' }}>
          <Box><Typography variant="h6" fontWeight={800}>Data</Typography><Typography variant="caption" color="text.secondary">{response.row_count ?? rows.length} rows</Typography></Box>
          <TextField size="small" label="Quick search" value={search} onChange={(e) => setSearch(e.target.value)} sx={{ minWidth: 240 }} />
        </Box>
        <Box sx={{ width: '100%' }}>
          <DataGrid
            rows={filtered}
            columns={columns}
            autoHeight
            disableRowSelectionOnClick
            pageSizeOptions={[10, 25, 50, 100]}
            initialState={{ pagination: { paginationModel: { pageSize: 10, page: 0 } } }}
            sx={{ border: 0, '& .MuiDataGrid-columnHeaders': { bgcolor: 'action.hover' } }}
          />
        </Box>
      </CardContent>
    </Card>
  );
}
