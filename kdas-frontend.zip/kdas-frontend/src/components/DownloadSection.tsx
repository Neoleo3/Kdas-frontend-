import { Alert, Button, Card, CardContent, Stack, Typography } from '@mui/material';
import DownloadRoundedIcon from '@mui/icons-material/DownloadRounded';
import ImageRoundedIcon from '@mui/icons-material/ImageRounded';
import TableViewRoundedIcon from '@mui/icons-material/TableViewRounded';
import CodeRoundedIcon from '@mui/icons-material/CodeRounded';
import PictureAsPdfRoundedIcon from '@mui/icons-material/PictureAsPdfRounded';
import type { AnalyticsResponse } from '../models/AnalyticsResponse';
import { downloadChartPng, downloadChartSvg, downloadCsv, downloadExcel, downloadJson, downloadReportPdf } from '../utils/downloads';

interface Props { response: AnalyticsResponse; reportRef: React.RefObject<HTMLDivElement | null>; chartRef: React.RefObject<HTMLDivElement | null>; }

export function DownloadSection({ response, reportRef, chartRef }: Props) {
  const data = response.data || [];
  const run = async (fn: () => void | Promise<void>) => { try { await fn(); } catch (error) { console.error(error); } };
  return <Card sx={{ mt: 2.5 }}><CardContent>
    <Typography variant="h6" fontWeight={800}>Download</Typography>
    <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>Export the returned analysis without modifying backend chart payloads.</Typography>
    {!data.length && !response.chart?.plotly?.data?.length ? <Alert severity="info">There is no data or chart available to export.</Alert> : null}
    <Stack direction="row" spacing={1} useFlexGap flexWrap="wrap">
      <Button startIcon={<TableViewRoundedIcon />} variant="outlined" disabled={!data.length} onClick={() => run(() => downloadCsv(data))}>CSV</Button>
      <Button startIcon={<CodeRoundedIcon />} variant="outlined" onClick={() => run(() => downloadJson(response))}>JSON</Button>
      <Button startIcon={<TableViewRoundedIcon />} variant="outlined" disabled={!data.length} onClick={() => run(() => downloadExcel(data))}>Excel</Button>
      <Button startIcon={<ImageRoundedIcon />} variant="outlined" disabled={!chartRef.current} onClick={() => run(() => downloadChartPng(chartRef.current!, 'kdas-chart.png'))}>Chart PNG</Button>
      <Button startIcon={<ImageRoundedIcon />} variant="outlined" disabled={!chartRef.current} onClick={() => run(() => downloadChartSvg(chartRef.current!, 'kdas-chart.svg'))}>Chart SVG</Button>
      <Button startIcon={<PictureAsPdfRoundedIcon />} variant="contained" disabled={!reportRef.current} onClick={() => run(() => downloadReportPdf(reportRef.current!, response.headline || 'KDAS Analytics Report'))}>Report PDF</Button>
      <Button startIcon={<DownloadRoundedIcon />} variant="text" onClick={() => window.print()}>Print</Button>
    </Stack>
  </CardContent></Card>;
}
