import axios from 'axios';
import { API_CONFIG, getRuntimeApiKey } from './config';
import type { AnalyticsResponse, QueryRequest } from '../models/AnalyticsResponse';

const mockEnabled = String(import.meta.env.VITE_MOCK_MODE).toLowerCase() === 'true';

const mockResponse: AnalyticsResponse = {
  headline: 'Monthly Comparison of Open vs Closed Requests',
  answer: 'Closed requests increased during the most recent period while open requests remained comparatively stable.',
  insights: [
    'Closed requests peaked in the latest month.',
    'Open requests show a flatter trend than closed requests.',
    'The latest month should be reviewed for unusually high closure volume.'
  ],
  data: [
    { month: 'Apr', status: 'Open', requests: 182 },
    { month: 'Apr', status: 'Closed', requests: 145 },
    { month: 'May', status: 'Open', requests: 190 },
    { month: 'May', status: 'Closed', requests: 168 },
    { month: 'Jun', status: 'Open', requests: 188 },
    { month: 'Jun', status: 'Closed', requests: 203 },
    { month: 'Jul', status: 'Open', requests: 196 },
    { month: 'Jul', status: 'Closed', requests: 229 }
  ],
  columns: ['month', 'status', 'requests'],
  chart: {
    type: 'line',
    title: 'Open vs Closed Requests',
    plotly: {
      data: [
        { x: ['Apr', 'May', 'Jun', 'Jul'], y: [182, 190, 188, 196], type: 'scatter', mode: 'lines+markers', name: 'Open' },
        { x: ['Apr', 'May', 'Jun', 'Jul'], y: [145, 168, 203, 229], type: 'scatter', mode: 'lines+markers', name: 'Closed' }
      ],
      layout: { xaxis: { title: 'Month' }, yaxis: { title: 'Requests' }, hovermode: 'x unified' }
    }
  },
  row_count: 8,
  telemetry: { input_tokens: 842, output_tokens: 421, total_tokens: 1263, duration_seconds: 3.4, llm_calls: 4 }
};

export async function runAnalyticsQuery(payload: QueryRequest): Promise<AnalyticsResponse> {
  if (mockEnabled) {
    await new Promise((resolve) => setTimeout(resolve, 900));
    return mockResponse;
  }

  if (!API_CONFIG.BASE_URL) {
    throw new Error('VITE_BASE_URL is not configured. Copy .env.example to .env and set your KDAS backend URL.');
  }

  const apiKey = getRuntimeApiKey();
  const response = await axios.post<AnalyticsResponse>(
    `${API_CONFIG.BASE_URL}/api/v1/analytics/query`,
    payload,
    {
      headers: apiKey ? { 'X-API-Key': apiKey } : undefined,
      timeout: 120000
    }
  );

  return response.data;
}
