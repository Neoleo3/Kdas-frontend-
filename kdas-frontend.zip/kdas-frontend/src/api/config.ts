export const API_CONFIG = {
  BASE_URL: (import.meta.env.VITE_BASE_URL || '').replace(/\/$/, ''),
  API_KEY: import.meta.env.VITE_API_KEY || ''
};

export function getRuntimeApiKey(): string {
  return sessionStorage.getItem('kdas_api_key') || API_CONFIG.API_KEY;
}

export function setRuntimeApiKey(value: string): void {
  const trimmed = value.trim();
  if (trimmed) sessionStorage.setItem('kdas_api_key', trimmed);
  else sessionStorage.removeItem('kdas_api_key');
}
