import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import type { AnalyticsResponse } from '../models/AnalyticsResponse';

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

export function downloadCsv(data: Array<Record<string, unknown>>, filename = 'kdas-data.csv') {
  if (!data.length) return;
  const keys = Array.from(new Set(data.flatMap((row) => Object.keys(row))));
  const escape = (value: unknown) => `"${String(value ?? '').replace(/"/g, '""')}"`;
  const csv = [keys, ...data.map((row) => keys.map((key) => row[key]))].map((row) => row.map(escape).join(',')).join('\n');
  downloadBlob(new Blob([csv], { type: 'text/csv;charset=utf-8' }), filename);
}

export function downloadJson(response: AnalyticsResponse, filename = 'kdas-analysis.json') {
  downloadBlob(new Blob([JSON.stringify(response, null, 2)], { type: 'application/json;charset=utf-8' }), filename);
}

export function downloadExcel(data: Array<Record<string, unknown>>, filename = 'kdas-data.xlsx') {
  if (!data.length) return;
  const workbook = XLSX.utils.book_new();
  const sheet = XLSX.utils.json_to_sheet(data);
  XLSX.utils.book_append_sheet(workbook, sheet, 'Analysis Data');
  XLSX.writeFile(workbook, filename);
}

export async function downloadChartPng(element: HTMLElement, filename = 'kdas-chart.png') {
  const canvas = await html2canvas(element, { backgroundColor: '#ffffff', scale: 2, useCORS: true });
  canvas.toBlob((blob) => blob && downloadBlob(blob, filename), 'image/png');
}

export async function downloadChartSvg(element: HTMLElement, filename = 'kdas-chart.svg') {
  const svg = element.querySelector('svg');
  if (!svg) throw new Error('No SVG chart found.');
  const serializer = new XMLSerializer();
  const source = serializer.serializeToString(svg);
  const blob = new Blob([source], { type: 'image/svg+xml;charset=utf-8' });
  downloadBlob(blob, filename);
}

export async function downloadReportPdf(element: HTMLElement, title: string) {
  const canvas = await html2canvas(element, { backgroundColor: '#ffffff', scale: 1.5, useCORS: true });
  const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  const margin = 10;
  const width = pageWidth - margin * 2;
  const height = (canvas.height * width) / canvas.width;
  pdf.setFontSize(16);
  pdf.text(title || 'KDAS Analytics Report', margin, margin + 2);
  let y = margin + 8;
  let remaining = height;
  let sourceY = 0;
  const usableHeight = pageHeight - y - margin;

  while (remaining > 0) {
    const sliceHeight = Math.min(remaining, usableHeight);
    const sliceCanvas = document.createElement('canvas');
    sliceCanvas.width = canvas.width;
    sliceCanvas.height = Math.round((sliceHeight / width) * canvas.width);
    const ctx = sliceCanvas.getContext('2d');
    if (!ctx) break;
    ctx.drawImage(canvas, 0, sourceY, canvas.width, sliceCanvas.height, 0, 0, sliceCanvas.width, sliceCanvas.height);
    const slice = sliceCanvas.toDataURL('image/png');
    pdf.addImage(slice, 'PNG', margin, y, width, sliceHeight);
    remaining -= sliceHeight;
    sourceY += sliceCanvas.height;
    if (remaining > 0) {
      pdf.addPage();
      y = margin;
    }
  }
  pdf.save('kdas-report.pdf');
}
