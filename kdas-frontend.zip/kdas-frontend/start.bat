@echo off
setlocal
if not exist node_modules (
  echo Installing dependencies...
  npm install
)
echo Starting KDAS Analytics Frontend...
npm run dev
